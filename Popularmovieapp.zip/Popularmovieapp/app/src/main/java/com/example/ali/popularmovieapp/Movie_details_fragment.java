package com.example.ali.popularmovieapp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;


public class Movie_details_fragment extends Fragment implements LoaderManager.LoaderCallbacks<Cursor> {
    private final int STATE_FAVOURITE = 1;
    private final int STATE_UNFAVOURITE = 0;
    private int currentState = 0;
    private final int LOADER_ID = 19;
    String moiveTitle, moivePoster, moiveOvreview, moiveDate;
    double moiveVote;
    int moiveId;
    Movie_data moiveObject;
    ArrayList<String> list = new ArrayList<String>();
    Treilar_array_adapter adapter;
    @BindView(R.id.favourite_icon)
    ImageView favourite;
    @BindView(R.id.trailer_list)
    ListView listView;
    @BindView(R.id.movie_title)
    TextView moive_title;
    @BindView(R.id.relased_date)
    TextView moive_date;
    @BindView(R.id.vote_average)
    TextView moive_rate;
    @BindView(R.id.movie_overview)
    TextView moive_overview;
    @BindView(R.id.details_moive_poster)
    ImageView moive_poster;
    @BindView(R.id.trailers_tx)
    TextView txView;

    public Movie_details_fragment() {
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        Bundle bundle = getArguments();
        moiveObject = bundle.getParcelable(getString(R.string.movie_object_key));
        getMovieData(moiveObject);
        if (Networking.isConnected(getActivity())) {
            fetchMovieVideoKey(moiveId);
        }
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getActivity().getSupportLoaderManager().initLoader(LOADER_ID, null, this);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.review_menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.review_item: {
                final String MOVIE_ID_KEY = "id";
                Intent intent = new Intent(getActivity(), Review.class);
                intent.putExtra(MOVIE_ID_KEY, moiveId);
                startActivity(intent);
                return true;
            }
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View newView = inflater.inflate(R.layout.movie_details_fragment, container, false);
        ButterKnife.bind(this, newView);
        moive_title.setText(moiveTitle);
        moive_date.setText(moiveDate);
        moive_rate.setText(String.valueOf(moiveVote));
        moive_overview.setText(moiveOvreview);

        if (Networking.isConnected(getActivity())) {
            Networking.loadMoivePoster(getActivity(), moive_poster, moivePoster);
        } else {
            moive_poster.setImageResource(R.drawable.movie_launch);
        }

        handleTrailers();
        checkConnectionForFavouriteView();

        return newView;
    }

    private void getMovieData(Movie_data movieObject) {
        moiveTitle = movieObject.getOriginal_title();
        moivePoster = movieObject.getPoster_Path();
        moiveOvreview = movieObject.getOverview();
        moiveDate = movieObject.getRelease_date();
        moiveVote = movieObject.getVote_average();
        moiveId = movieObject.getMoiveId();
    }


    public void fetchMovieVideoKey(int id) {
        RequestQueue queue = Volley.newRequestQueue(getActivity());

        String requestedUrl = Networking.buildTrailerURi(id).toString();
        JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.GET, requestedUrl, new Response.Listener<JSONObject>() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onResponse(JSONObject response) {
                try {
                    list = Networking.parseJsonTrailerUrlToString(response);
                    adapter = new Treilar_array_adapter(list, getActivity());
                    listView.setAdapter(adapter);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity(), getString(R.string.unexcepected_error), Toast.LENGTH_SHORT).show();
            }
        });

        queue.add(objectRequest);
    }

    public void handleTrailers() {
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String videoKey = list.get(i);
                startYoutube(videoKey);
            }
        });
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                String videoKey = list.get(i);
                shareTrailerVideoUrl(videoKey);
                return true;
            }
        });
    }

    private void startYoutube(String videoKey) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Networking.buildTrailerVideoUrl(videoKey));
        if (intent.resolveActivity(getActivity().getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    private void shareTrailerVideoUrl(String videoKey) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, moiveTitle);
        String sAux = "\n" + getString(R.string.recommendation_text) + "\n";
        sAux = sAux + Networking.buildTrailerVideoUrl(videoKey) + "\n";
        intent.putExtra(Intent.EXTRA_TEXT, sAux);
        startActivity(Intent.createChooser(intent, getString(R.string.choose_app)));
    }

    private void checkConnectionForFavouriteView() {
        if (!Networking.isConnected(getActivity())) {
            Toast.makeText(getActivity(), getString(R.string.offline_mode), Toast.LENGTH_SHORT).show();
            setHasOptionsMenu(false);
            listView.setVisibility(ListView.GONE);
            txView.setVisibility(TextView.GONE);
        }
    }

    private void handleFavouriteMoives() {
        favourite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buttonToggle();
            }
        });
    }

    private void insertMovieDataIntoDatabase() {
        ContentValues values = new ContentValues();
        values.put(Data_contract.MoiveEntry.MOIVE_ID, moiveId);
        values.put(Data_contract.MoiveEntry.TITLE, moiveTitle);
        values.put(Data_contract.MoiveEntry.OVERVIEW, moiveOvreview);
        values.put(Data_contract.MoiveEntry.PSTER_PATH, moivePoster);
        values.put(Data_contract.MoiveEntry.VOTE, moiveVote);
        values.put(Data_contract.MoiveEntry.RELASED_DATE, moiveDate);
        Uri uri = getActivity().getContentResolver().insert(Data_contract.MoiveEntry.CONTENT_URI, values);
        if (uri != null) {
            favourite.setImageResource(R.drawable.fav);
            Toast.makeText(getActivity(), getString(R.string.marked_Favourite), Toast.LENGTH_SHORT).show();
        }

    }

    private void deleteMovieDataFromDatabase() {
        String MovieIdStr = String.valueOf(moiveId);
        Uri uri = Data_contract.MoiveEntry.CONTENT_URI.buildUpon().appendPath(MovieIdStr).build();
        getActivity().getContentResolver().delete(uri, null, null);
        favourite.setImageResource(R.drawable.notfav);
        Toast.makeText(getActivity(), getString(R.string.marked_unFavourite), Toast.LENGTH_SHORT).show();
    }

    private void buttonToggle() {
        switch (currentState) {
            case STATE_FAVOURITE: {
                deleteMovieDataFromDatabase();
                currentState = STATE_UNFAVOURITE;
                break;
            }
            case STATE_UNFAVOURITE: {
                insertMovieDataIntoDatabase();
                currentState = STATE_FAVOURITE;
                break;
            }
        }
    }

    private int getFavouriteMovieIDFromDatabase(Cursor cursor) {
        int moiveId = -1;
        if (cursor.moveToFirst()) {
            do {
                moiveId = cursor.getInt(cursor.getColumnIndex(Data_contract.MoiveEntry.MOIVE_ID));
            } while (cursor.moveToNext());
        }
        return moiveId;
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        return new AsyncTaskLoader<Cursor>(getActivity()) {
            Cursor cursorData;

            @Override
            protected void onStartLoading() {
                if (cursorData != null) {
                    deliverResult(cursorData);
                } else {
                    forceLoad();
                }
            }

            @Override
            public Cursor loadInBackground() {
                try {
                    return getActivity().getContentResolver().query(
                            Data_contract.MoiveEntry.CONTENT_URI,
                            new String[]{Data_contract.MoiveEntry.MOIVE_ID},
                            Data_contract.MoiveEntry.MOIVE_ID + "=?",
                            new String[]{String.valueOf(moiveId)},
                            null
                    );
                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }
            }

            public void deliverResult(Cursor data) {
                cursorData = data;
                super.deliverResult(data);
            }
        };
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        if (data != null) {
            int movieIdInDatabase = getFavouriteMovieIDFromDatabase(data);
            if (movieIdInDatabase == moiveId) {
                favourite.setImageResource(R.drawable.fav);
                currentState = STATE_FAVOURITE;
            } else {
                favourite.setImageResource(R.drawable.notfav);
                currentState = STATE_UNFAVOURITE;
            }
            handleFavouriteMoives();
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
    }
}