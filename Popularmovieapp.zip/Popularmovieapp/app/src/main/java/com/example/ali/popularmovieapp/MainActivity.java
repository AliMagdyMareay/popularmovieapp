package com.example.ali.popularmovieapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements Data_listener{

    boolean isTwoPane=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Movie_main_fragment movieFragment=new Movie_main_fragment();

        if(savedInstanceState==null)
        {
            movieFragment.setListener(this);
            getSupportFragmentManager().beginTransaction().add(R.id.main_container, movieFragment).commit();
        }
        if(findViewById(R.id.details_container)!=null)
        {
            isTwoPane=true;
        }
    }

    @Override
    public void sendMovieData(Movie_data object) {
        if(!isTwoPane) {
            Intent intent=new Intent(this,Details.class);
            intent.putExtra(getString(R.string.movie_object_key),object);
            startActivity(intent);
        }
        else
        {
            Movie_details_fragment detalisFragment=new Movie_details_fragment();
            Bundle bundle=new Bundle();
            bundle.putParcelable(getString(R.string.movie_object_key),object);
            detalisFragment.setArguments(bundle);
            getSupportFragmentManager().beginTransaction().replace(R.id.details_container,detalisFragment).commit();
        }
    }
}
