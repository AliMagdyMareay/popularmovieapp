package com.example.ali.popularmovieapp;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.annotation.Nullable;

/**
 * Created by ali on 16-Mar-17.
 */

public class Movie_provider extends ContentProvider
{
    private static final UriMatcher URI_MATCHER=buildUriMatcher();
    private Movie_DB dbHelper;

    private static final int MOVIE=100;
    private static final int MOVIE_WITH_ID=200;

    private static UriMatcher buildUriMatcher()
    {
        UriMatcher matcher=new UriMatcher(UriMatcher.NO_MATCH);
        String authority=Data_contract.CONTENT_AUTHORITY;
        matcher.addURI(authority,Data_contract.MoiveEntry.TABLENAME,MOVIE);
        matcher.addURI(authority,Data_contract.MoiveEntry.TABLENAME + "/#",MOVIE_WITH_ID);
        return matcher;
    }

    @Override
    public boolean onCreate() {
        dbHelper=new Movie_DB(getContext());
        return true;
    }

    @Nullable
    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        Cursor retCursor;
        switch (URI_MATCHER.match(uri))
        {
            case MOVIE:
            {
                retCursor=dbHelper.getReadableDatabase().query(
                        Data_contract.MoiveEntry.TABLENAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder
                );
                return retCursor;
            }
            default:
            {
                throw new UnsupportedOperationException("Unknown Uri : "+uri);
            }
        }
    }

    @Nullable
    @Override
    public String getType(Uri uri) {
        final int match=URI_MATCHER.match(uri);
        switch (match) {
            case MOVIE:
                return Data_contract.MoiveEntry.CONTENT_DIR_TYPE;
            case MOVIE_WITH_ID:
                return Data_contract.MoiveEntry.CONT_ITEM_TYPE;
            default:
                throw new UnsupportedOperationException("Unknown URI : " + uri);
        }
    }

    @Nullable
    @Override
    public Uri insert(Uri uri, ContentValues contentValues) {
        final SQLiteDatabase db=dbHelper.getWritableDatabase();
        Uri retUri;
        switch (URI_MATCHER.match(uri))
        {
            case MOVIE:
            {
                long id=db.insert(Data_contract.MoiveEntry.TABLENAME,null,contentValues);
                if(id>0)
                {
                    retUri=Data_contract.MoiveEntry.buildMoivrUri(id);
                }
                else
                {
                    throw new android.database.SQLException("Failed to insert row into: " + uri);
                }
                break;
            }
            default:
                throw new UnsupportedOperationException("Unknown uri: " + uri);
        }
        getContext().getContentResolver().notifyChange(uri,null);
        return retUri;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        final SQLiteDatabase db=dbHelper.getWritableDatabase();
        int numDeleted;
        switch (URI_MATCHER.match(uri))
        {
            case MOVIE:
            {
                numDeleted=db.delete(Data_contract.MoiveEntry.TABLENAME,selection,selectionArgs);
                db.execSQL("DELETE FROM SQLITE_SEQUENCE WHERE NAME = '" +
                        Data_contract.MoiveEntry.TABLENAME + "'");
                break;
            }
            case MOVIE_WITH_ID:
            {
                String id=uri.getPathSegments().get(1);
                numDeleted=db.delete(Data_contract.MoiveEntry.TABLENAME,"movie_id=?",new String[]{id});
                db.execSQL("DELETE FROM SQLITE_SEQUENCE WHERE NAME = '" +
                        Data_contract.MoiveEntry.TABLENAME + "'");
                break;
            }
            default:
                throw new UnsupportedOperationException("Unknown uri: " + uri);
        }
        return numDeleted;
    }

    @Override
    public int update(Uri uri, ContentValues contentValues, String selection, String[] selectionArgs) {
        return 0;
    }
}
