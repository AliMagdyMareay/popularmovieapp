package com.example.ali.popularmovieapp;

/**
 * Created by ali on 16-Mar-17.
 */

public interface Data_listener {
    void sendMovieData(Movie_data object);

}
