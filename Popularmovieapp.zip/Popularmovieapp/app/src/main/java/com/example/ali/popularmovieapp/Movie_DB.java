package com.example.ali.popularmovieapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by ali on 16-Mar-17.
 */

public class Movie_DB extends SQLiteOpenHelper
{
    private static final String DATABASE_NAME="moive.db";
    private static final int DATABASE_VERSION=5;

    public Movie_DB(Context context) {
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        final String CREATE_TABLE_MOIVE=
                "CREATE TABLE " + Data_contract.MoiveEntry.TABLENAME + " ("+Data_contract.MoiveEntry._ID+ " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        Data_contract.MoiveEntry.MOIVE_ID + " INTEGER UNIQUE NOT NULL, "+
                        Data_contract.MoiveEntry.TITLE + " TEXT NOT NULL, "+
                        Data_contract.MoiveEntry.OVERVIEW + " TEXT NOT NULL, "+
                        Data_contract.MoiveEntry.PSTER_PATH + " TEXT NOT NULL, "+
                        Data_contract.MoiveEntry.RELASED_DATE + " TEXT NOT NULL, "+
                        Data_contract.MoiveEntry.VOTE + " REAL NOT NULL "+");";
        sqLiteDatabase.execSQL(CREATE_TABLE_MOIVE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + Data_contract.MoiveEntry.TABLENAME);
        onCreate(sqLiteDatabase);
    }
}
