package com.example.ali.popularmovieapp;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by ali on 16-Mar-17.
 */

public class Review_class implements Parcelable
{
    String reviewAuthor,reviewContent;
    public Review_class(String reviewAuthor, String reviewContent) {
        this.reviewAuthor = reviewAuthor;
        this.reviewContent = reviewContent;
    }
    private Review_class(Parcel in)
    {
        reviewAuthor=in.readString();
        reviewContent=in.readString();
    }
    public String getReviewAuthor() {
        return reviewAuthor;
    }

    public String getReviewContent() {
        return reviewContent;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(reviewAuthor);
        parcel.writeString(reviewContent);
    }

    public static final Creator<Review_class> CREATOR= new Creator<Review_class>() {
        @Override
        public Review_class createFromParcel(Parcel parcel) {
            return new Review_class(parcel);
        }

        @Override
        public Review_class[] newArray(int i) {
            return new Review_class[i];
        }
    };
}
