package com.example.ali.popularmovieapp;


import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import java.util.ArrayList;

public class Movie_array_adapter extends BaseAdapter
{
    static class ViewHolder {
        ImageView imageView;
    }

    Activity activity;
    ArrayList<Movie_data> list = new ArrayList<Movie_data>();

    public Movie_array_adapter(Activity activity, ArrayList<Movie_data> list) {
        this.activity = activity;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int i) {
        return list.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        if (view == null) {
            LayoutInflater inflater = activity.getLayoutInflater();
            view = inflater.inflate(R.layout.movie_item, viewGroup, false);
            viewHolder = new ViewHolder();
            viewHolder.imageView = (ImageView) view.findViewById(R.id.moive_poster);
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();
        }
        String poster_uri = list.get(i).getPoster_Path();

        if (Networking.isConnected(activity)) {
            Networking.loadMoivePoster(activity, viewHolder.imageView, poster_uri);
        } else {
            viewHolder.imageView.setImageResource(R.drawable.movie_launch);
        }
        return view;
    }

}
